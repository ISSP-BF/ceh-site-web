( function( $ ) {
    // Add Color Picker to all inputs that have 'color-field' class
    $( function() {
        $( '.eap__color-field' ).wpColorPicker();
    });
} )( jQuery );
