<?php
// settings page
require ( plugin_dir_path( __FILE__ ) . 'settings/eap-settings-page.php' );
// register settings
require ( plugin_dir_path( __FILE__ ) . 'settings/eap-register-settings.php' );
// display settings
require ( plugin_dir_path( __FILE__ ) . 'settings/eap-display-settings.php' );
