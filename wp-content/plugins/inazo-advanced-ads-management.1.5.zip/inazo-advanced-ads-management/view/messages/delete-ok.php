<?php
if( !defined( 'ABSPATH' ) ){
	
	exit(-1);
}
?>

<div class="updated">
	<p><?php _e( 'The ads was succesfully removed.','inazo-adv-ads-manager' ); ?></p>
</div>