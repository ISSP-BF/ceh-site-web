=== Plugin Name ===
Contributors: inazo
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=9E7RUJAAHB5C2
Tags: ads, publicity, publicité, pub, widget
Requires at least: 4.5.1
Tested up to: 4.9.1
Stable tag: 1.5
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html 

This plugin is an ads manager, that allow you to add ads with widget on your website.

== Description ==

Advanced ads manager 

This plugin is an ads manager, that allow you to add ads with widget on your website.

Functionnality :

- Widget for included in website
- Ads from HTML code or Media library from Wordpress
- Defined start date and end date for publication
- Can add href link the ads
- multi ads by fading with jQuery
- No limit ads show by widget
- Can change order to show multiple ads (by start date, end date, random)

----- Francais ------

Fonctionnalités :

- Un widget pour afficher une ou plusieurs publicités à plusieurs endroit de votre site
- Création des publicités soit avec un code HTML (provenant d'un partenaire ou d'une régie) ou des images présentent dans la bibliothèque wordpress.
- De définir une date de début et une date de fin
- D'ajouter un lien sur la publicité avec possibilité de l'ouvrir dans un nouvel onglet
- Effet de fading pour afficher une rotation de publicité sur un seul emplacement (pas de limite du nombre de publicité)
- Possibilité d'ordonner les publicités suivant : la date de début, la date de fin ou en aléatoire

Credits picture : http://fr.freepik.com/vecteurs-libre/bannieres-d-39-affaires-en-ligne_791781.htm

== CHANGELOG ==


= 1.5 =
* Factorisation of code

= 1.4 =
* Fix minor security issue : https://wpvulndb.com/vulnerabilities/8621

= 1.3 = 
* improve ergnomie
* add french and japanese translation

= 1.2 = 
* fix include error in PHP file

= 1.1 = 
* fix jquery good practice
* enforcement of security
* improve performance and js for multi ads 

= 1.0 =
* init version

