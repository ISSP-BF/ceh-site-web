jQuery('.subscribe-message').show();
jQuery('.subscribe-message').fadeOut(3000);

 