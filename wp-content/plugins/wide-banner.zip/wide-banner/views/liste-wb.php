<div class="wrap">
    <h1><?php _e( 'Wide Banner', 'wide_bn' ); ?></h1>
    <hr>
   
    
</div>
